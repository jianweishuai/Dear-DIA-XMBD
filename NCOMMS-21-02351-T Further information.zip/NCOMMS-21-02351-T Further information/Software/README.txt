//====================================================
//  Software requirements (third party)
//====================================================
	Miniconda3 (Version 4.5.11)
	MXNet (Version >= 1.5.0)
	MSconvert (Proteowizard, Version 3.0.19311)
	TPP (Trans-Proteomic Pipeline, Version 4.8)
	Comet (Version 2017.01)
	X!Tandem (Version 2013.06.15.1, native and k-score)
	OpenMS (Version 2.2.0)
	Pyprophet (Pyprophet-cli v0.19)
	
Description: 
Miniconda3 (Version 4.5.11) can be download at https://repo.anaconda.com/miniconda/.
MXNet (Version >= 1.5.0) can be download at https://pypi.org/project/mxnet/
MSconvert (proteowizard, Version 3.0.4472) can be downloaded at http://proteowizard.sourceforge.net/download.html.
TPP (Trans Proteomics Pipeline, Version 4.8) can be downloaded at http://tools.proteomecenter.org/wiki/index.php?title=Software:TPP.
Comet and X!Tandem are included in TPP (Version 4.8).
OpenMS (Version 2.2.0) can be downloaded at https://github.com/OpenMS/OpenMS/releases.
Pyprophet (Pyprophet-cli v0.19) can be downloaded at https://github.com/PyProphet.

//====================================================
//  Instructions of Dear-DIA-XMBD
//====================================================
Description of the "./Dear-DIA" folder:

./Dear-DIA
    +deardia.configure.new
    +Dear-DIA.exe
    +deep_vae_mxnet.params
    +deep_vae_mxnet-symbol.json
    +vcomp140.dll

"deardia.configure.new": the configuration file of Dear-DIA-XMBD.
"Dear-DIA.exe": the releases binary package of Dear-DIA-XMBD.
"deep_vae_mxnet.params": the parameter file of deep variational autoencoder.
"deep_vae_mxnet-symbol.json": the parameter file of deep variational autoencoder.
"vcomp140.dll": windows runtime environment

Using Dear-DIA-XMBD only need 3 steps.

1. Install Miniconda3 and MXNet (a deep learning framework).
2. Setting the parameters in "deardia.configure.new" file.
3. Run "Dear-DIA.exe --cf deardia.configure.new --out_dir /path/to/dir/ --in /path/to/xx.mzXML"

Notes: 
"--cf": configure file of Dear-DIA.exe.
"--out_dir": output directory or path.
"--in": input file with mzXML format.

"/path/to/dir/" indicates the output folder.
"/path/to/xx.mzXML" indicates the path of input mzXML file (xx.mzXML is a virtual name).

Output:
Dear-DIA-XMBD will output xx.mgf file in the specific folder: "--out_dir".

================= Step1. Install Miniconda3 and MXNet ==================

The tutorial for installing dependents of Dear-DIA-XMBD can be found in the "installation.pdf" file.

1. Install Miniconda3 package.
(1) Download "Miniconda3-4.5.11-Windows-x86_64.exe" (package size: 52.8MB) from https://repo.anaconda.com/miniconda/.
(2) Double click the package to install Miniconda3.
(3) We assume that miniconda3 is installed in the path: "C:/Miniconda3"

2. Install MXNet deep learning framework 

---------------- MXNet CPU version -------------------
(1) Open "Anaconda Prompt (miniconda3)" and enter the following command: 
	pip install mxnet

(2) Copy *.dll files from "C:\Miniconda3\Lib\site-packages\mxnet" to the folder where Dear-DIA.exe is located.

The *.dll include the follwing files:

	libgcc_s_seh-1.dll
	libgfortran-3.dll
	libmxnet.dll
	libopenblas.dll
	libquadmath-0.dll

---------------- MXNet GPU version -------------------
If you have at least one NVIDIA GPU device, you can use it to accelerate Dear-DIA-XMBD.

In this case, you need to install NVIDIA CUDA 10.0 toolkit and cuDNN v7.6.5.

The tutorial for installing CUDA and cuDNN can be found in the "installation.pdf" file.

After installing CUDA and cuDNN, you need to install MXNet with GPU version.

(1) Open "Anaconda Prompt (miniconda3)" and enter the following command: 
	pip install mxnet-cu100

(2) Copy *.dll files from "C:\Miniconda3\Lib\site-packages\mxnet" to the folder where Dear-DIA.exe is located.

The *.dll include the follwing files:
	
	cudnn64_7.dll
	libgcc_s_seh-1.dll
	libgfortran-3.dll
	libmxnet.dll
	libopenblas.dll
	libquadmath-0.dll

=============== Step2. Setting the parameters of Dear-DIA-XMBD ===========

If there is no "deardia.configure.new" file in the "./Dear-DIA" folder, please run the following command in windows CMD:
	"Dear-DIA.exe --p"

You need to set 4 parameters in "deardia.configure.new" file.

"database_name": the path of db.fasta file.
"window_file_name": the path of MS1 isolation window file.
"mxnet_json_file_name": the path of deep_vae_mxnet-symbol.json. (you can found this file in the path of Dear-DIA.exe)
"mxnet_params_file_name": the path of deep_vae_mxnet-symbol.json. (you can found this file in the path of Dear-DIA.exe)
"GPU": the option of using GPU acceleration.

The contents of "deardia.configure.new" file is shown in the following:
----------------------------------------------------------------------
# deardia version v1.0.0
# deardia parameters file. 
# Everything following the '#' symbol means comment.

database_name = /path/to/db.fasta
window_file_name = /path/to/win.100.tsv
mxnet_json_file_name = /path/to/deep_vae_mxnet-symbol.json
mxnet_params_file_name = /path/to/deep_vae_mxnet.params

GPU = 0 	#1: use GPU acceleration; 0: not use GPU device.
num_threads = 0 	#0=use all CPU threads; else specify num threads directly.
# Up to 3 variable modifications per peptide are supported. 
# format <mass>@<residues>
# Note: 42.0106@n specify represent Acetylation
variable_mod = 42.0106@n
variable_mod = 15.9949@M
#variable_mod = 79.96633@STY

buffer_size = 4096	#buffer space size when loading mzXML file.
slider_strides = 1	#overlap of neighboring sliders.
batch_size = 512	#batch size of deep auto-encoder inputs.
n_clusters = 20	#number of clusters in k-means.
min_hit_num = 6	#hit b ions + hit y ions >= 6.
precursor_min_charge = 2	#precursor min charge.
precursor_max_charge = 4	#precursor max charge.
fragment_min_charge = 1	#minimum charge of fragment.
fragment_max_charge = 2	#maximum charge of fragment.
fragment_min_mz = 100	#fragment min m/z
fragment_max_mz = 1800	#fragment max m/z
pep_min_length = 7	#minimum length of peptides
pep_max_length = 40	#maximum length of peptides
miss_cleavage = 2	#miss cleavage of enzyme digestion 
ms1_tol_ppm = 50	#tolerance of ms1 m/z (unit: ppm)
ms2_tol_ppm = 100	#tolerance of ms2 m/z (unit: ppm)
decoy_prefix = DECOY_	#prefix of decoy proteins in fasta database

#Advance options
#Warning: larger queue size will cost more memory.
slider_queue_size = 16	#the size of slider concurrency queue.
cluster_queue_size = 512	#the size of clustering concurrency queue
deeplearning_queue_size = 256	#the size of deeplearning concurrency queue
----------------------------------------------------------------------------

========================== Step3. Run Dear-DIA.exe ========================

After installing the dependents of Dear-DIA.exe and setting the parameters, you can use the following command in windows CMD to run Dear-DIA.exe:

	Dear-DIA.exe --cf deardia.configure.new --out_dir /path/to/dir/ --in /path/to/xx.mzXML
	
The output xx.mgf file can be found in "/path/to/dir/".
